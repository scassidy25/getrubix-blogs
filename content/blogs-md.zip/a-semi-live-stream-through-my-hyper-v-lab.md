---
title: "A semi Live-stream Through My Hyper-V Lab"
slug: "/blog/a-semi-live-stream-through-my-hyper-v-lab"
date: "Mon, 21 Aug 2023 21:28:15 +0000"
author: "stevew1015@gmail.com"
description: " In preparing to make some YouTube content detailing the tenant-to-tenant migration process, I realized I needed to bake some Hyper-V virtual machines. But alas; I found myself fresh out of any Windows 10 22H2 builds.This would mean I needed to make one. And I figured, if"
thumbnail: "https://getrubixsitecms.blob.core.windows.net/public-assets/content/v1/logo512.png"
---

In preparing to make some YouTube content detailing the tenant-to-tenant migration process, I realized I needed to bake some Hyper-V virtual machines. But alas; I found myself fresh out of any Windows 10 22H2 builds.

This would mean I needed to make one. And I figured, if I’m going to go through that process anyway, why not record it? Or better yet, live-stream it? Okay, okay… I ended up just recording it. But it might just be long winded enough to feel like a stream…

For the blog post with the **CreateVM** PowerShell script, go [here](https://www.getrubix.com/blog/hyped-up-hyper-v).
