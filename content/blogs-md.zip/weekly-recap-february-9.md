---
title: "Weekly Recap February 9"
slug: "/blog/weekly-recap-february-9"
date: "Fri, 09 Feb 2024 15:45:13 +0000"
author: "stevew1015@gmail.com"
description: " function introComment($weekOfMonth, $busyValue, $funnyThing) { $commentOutput = "That is it for $($weekOfMonth.week), it sure has been $($busyValue.value)." + " " + $($funnyThing) "
thumbnail: "https://getrubixsitecms.blob.core.windows.net/public-assets/content/v1/logo512.png"
---

```
function introComment($weekOfMonth, $busyValue, $funnyThing)
{
    $commentOutput = "That is it for $($weekOfMonth.week), it sure has been 
                      $($busyValue.value)." + " " + $($funnyThing)
     return $commentOutput
}
```

Intune Device Migration: V6
---------------------------

I skipped right over V4 and V5 to bring you this. Even took the phrase “tenant-to-tenant” out of here since we can migrate from domain join state to pure cloud joined. The first major update is coming next week already (so 6.1?) but you can grab it here:  
https://github.com/stevecapacity/Intune-Device-Migration-V6

How to Deploy Autopilot Branding with Intune
--------------------------------------------

I almost didn’t make this because I thought to myself “at this point who isn’t using the Autopilot Branding tool?” It turns out, I was wrong. You can grab it here:

https://github.com/mtniehaus/AutopilotBranding

Intel NUC Server Ethernet Fix
-----------------------------

Bit of an update on my home NUC server setup: once I upgraded to Windows Server 2022, the PC had no idea it contained a network card. So I found a cheap workaround.

GETRUBIX PODCAST: Episode 10 - Intune Suite
-------------------------------------------

Dustin is back and we chat about the latest Intune Suite features to drop this week.

Until next week…
