---
title: "Windows 11 Autopilot Enrollment"
slug: "/blog/windows-11-autopilot-enrollment"
date: "Tue, 21 Jun 2022 19:39:45 +0000"
author: "stevew1015@gmail.com"
description: " Time for something a bit different. You see, I’ve been helping several organizations over the last few weeks test Windows 11 enrollments to Intune via Autopilot. I’ve come across a few things that are particularly interesting.“You’re just talking about Windows again, Steve… what’s different?” Glad"
thumbnail: "https://getrubixsitecms.blob.core.windows.net/public-assets/content/v1/logo512.png"
---

Time for something a bit different. You see, I’ve been helping several organizations over the last few weeks test Windows 11 enrollments to Intune via Autopilot. I’ve come across a few things that are particularly interesting.

“You’re just talking about Windows again, Steve… what’s _different_?” Glad you asked. Instead of just typing about the experience, I thought it would be better for all of us if I just show you. So with that, we’re really excited to introduce you to the official Get Rubix Youtube channel. And with it, here is our first upload, where I take you through a Windows 11 enrollment.
